package com.pavelsklenar.radiuslogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RadiusLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(RadiusLoginApplication.class, args);
	}
}
