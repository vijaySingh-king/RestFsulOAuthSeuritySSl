package com.pavelsklenar.sslclientauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SslClientAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslClientAuthApplication.class, args);
	}
}
