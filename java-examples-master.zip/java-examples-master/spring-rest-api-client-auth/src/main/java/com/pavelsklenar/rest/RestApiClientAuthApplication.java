package com.pavelsklenar.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiClientAuthApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiClientAuthApplication.class, args);
	}
}
